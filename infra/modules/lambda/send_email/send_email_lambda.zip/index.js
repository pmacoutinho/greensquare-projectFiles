//index.js

const { SESClient, SendEmailCommand } = require("@aws-sdk/client-ses");

const ses = new SESClient({ region: "us-east-1" });

exports.handler = async (event) => {
  const command = new SendEmailCommand({
    Destination: {
      ToAddresses: ["pedro.giveaway@gmail.com"],
    },
    Message: {
      Body: {
        Text: { Data: "Your transaction is confirmed" },
      },
      Subject: { Data: "GreenSquare: Transaction Confirmation" },
    },
    Source: "pedro.giveaway@gmail.com",
  });

  try {
    let response = await ses.send(command);
    return response;
  } catch (error) {
    console.error("Error sending email:", error);
    throw error;
  }
};
